public class holder{
  public static final PanelManager pManage = new PanelManager();
}
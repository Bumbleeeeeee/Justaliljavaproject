class ComputerPlayer extends Player {

  public ComputerPlayer() {
    
  }

  public int[][] getMove() {
    return easy();
  }

  public int[][] easy() {
    
  } 
  
}